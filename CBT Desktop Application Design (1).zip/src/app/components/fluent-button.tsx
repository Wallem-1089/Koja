import { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "./ui/utils";

interface FluentButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost";
  children: ReactNode;
}

export function FluentButton({
  variant = "primary",
  className,
  children,
  ...props
}: FluentButtonProps) {
  return (
    <button
      className={cn(
        "px-4 py-2 rounded-lg transition-all duration-200 font-medium flex items-center justify-center gap-2",
        variant === "primary" &&
          "bg-[#0078D4] text-white hover:bg-[#106EBE] active:bg-[#005A9E] shadow-sm",
        variant === "secondary" &&
          "bg-white text-[#1F1F1F] border border-[#E1E1E1] hover:bg-[#F3F3F3] active:bg-[#E1E1E1]",
        variant === "ghost" &&
          "bg-transparent text-[#1F1F1F] hover:bg-[#F3F3F3] active:bg-[#E1E1E1]",
        "disabled:opacity-50 disabled:cursor-not-allowed",
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
