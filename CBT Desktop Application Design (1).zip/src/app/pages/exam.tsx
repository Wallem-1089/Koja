import { useState, useEffect } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router";
import { FluentButton } from "../components/fluent-button";
import { FluentRadio } from "../components/fluent-radio";
import { ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "../components/ui/utils";

// Sample questions data
const sampleQuestions = [
  {
    id: 1,
    question: "2 · 27",
    options: ["48", "54", "56", "64"],
  },
  {
    id: 2,
    question: "What is the derivative of x²?",
    options: ["x", "2x", "x³", "2"],
  },
  {
    id: 3,
    question: "Solve: 3x + 5 = 20",
    options: ["x = 3", "x = 5", "x = 7", "x = 15"],
  },
  {
    id: 4,
    question: "What is the value of π (pi) approximately?",
    options: ["3.14", "2.71", "1.41", "1.61"],
  },
];

// Generate 24 questions by repeating the sample
const generateQuestions = () => {
  const questions = [];
  for (let i = 0; i < 24; i++) {
    const sample = sampleQuestions[i % sampleQuestions.length];
    questions.push({
      ...sample,
      id: i + 1,
      question: sample.question,
    });
  }
  return questions;
};

export function Exam() {
  const navigate = useNavigate();
  const { subject } = useParams();
  const [searchParams] = useSearchParams();
  const duration = parseInt(searchParams.get("duration") || "30");

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [timeRemaining, setTimeRemaining] = useState(duration * 60); // Convert to seconds
  const questions = generateQuestions();

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleSubmit = () => {
    navigate("/results", {
      state: {
        answers,
        totalQuestions: questions.length,
        subject,
      },
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleAnswer = (optionIndex: number) => {
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion]: optionIndex,
    }));
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="flex flex-col h-screen bg-[#F3F3F3] overflow-hidden">
      {/* Header */}
      <header className="bg-white border-b border-[#E1E1E1] px-6 py-4 flex items-center justify-between shadow-sm backdrop-blur-xl bg-opacity-95">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate("/dashboard")}
            className="p-2 hover:bg-[#F3F3F3] rounded-lg transition-colors duration-200"
          >
            <ArrowLeft className="size-5 text-[#1F1F1F]" />
          </button>
          <h1 className="text-lg font-semibold text-[#1F1F1F]">CBT App - {subject}</h1>
        </div>

        <div
          className={cn(
            "px-6 py-2 rounded-lg font-semibold text-lg",
            timeRemaining < 60 ? "bg-[#FDE7E9] text-[#D13438]" : "bg-[#FFF4CE] text-[#CA5010]"
          )}
        >
          {formatTime(timeRemaining)}
        </div>
      </header>

      {/* Progress Bar */}
      <div className="bg-[#E1E1E1] h-1">
        <div
          className="bg-[#0078D4] h-full transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-8">
        <div className="max-w-4xl mx-auto">
          {/* Question Card */}
          <div className="bg-white rounded-xl border border-[#E1E1E1] p-8 shadow-sm mb-6">
            <div className="mb-6">
              <span className="text-sm font-medium text-[#717171]">
                Question {currentQuestion + 1}/{questions.length}
              </span>
              <h2 className="text-2xl font-semibold text-[#1F1F1F] mt-2">
                {questions[currentQuestion].question}
              </h2>
            </div>

            {/* Options */}
            <div className="space-y-3">
              {questions[currentQuestion].options.map((option, index) => (
                <FluentRadio
                  key={index}
                  label={option}
                  option={String.fromCharCode(65 + index)}
                  name={`question-${currentQuestion}`}
                  checked={answers[currentQuestion] === index}
                  onChange={() => handleAnswer(index)}
                />
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mb-6">
            <FluentButton
              variant="secondary"
              onClick={() => setCurrentQuestion((prev) => Math.max(0, prev - 1))}
              disabled={currentQuestion === 0}
              className="gap-1"
            >
              <ChevronLeft className="size-5" />
              Previous
            </FluentButton>

            <FluentButton
              variant="primary"
              onClick={handleSubmit}
              className="px-8"
            >
              Submit Exam
            </FluentButton>

            <FluentButton
              variant="secondary"
              onClick={() =>
                setCurrentQuestion((prev) => Math.min(questions.length - 1, prev + 1))
              }
              disabled={currentQuestion === questions.length - 1}
              className="gap-1"
            >
              Next
              <ChevronRight className="size-5" />
            </FluentButton>
          </div>

          {/* Question Grid */}
          <div className="bg-white rounded-xl border border-[#E1E1E1] p-6 shadow-sm">
            <h3 className="text-sm font-semibold text-[#1F1F1F] mb-4">Question Navigator</h3>
            <div className="grid grid-cols-12 gap-2">
              {questions.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentQuestion(index)}
                  className={cn(
                    "size-10 rounded-lg text-sm font-medium transition-all duration-200 border-2",
                    currentQuestion === index
                      ? "bg-[#0078D4] text-white border-[#0078D4] shadow-md"
                      : answers[index] !== undefined
                      ? "bg-[#00B7C3] text-white border-[#00B7C3]"
                      : "bg-white text-[#1F1F1F] border-[#E1E1E1] hover:border-[#0078D4]"
                  )}
                >
                  {index + 1}
                </button>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}