import { useState } from "react";
import { useNavigate } from "react-router";
import { Sidebar } from "../components/sidebar";
import { FluentButton } from "../components/fluent-button";
import { BookOpen, Clock } from "lucide-react";

const subjects = [
  { code: "ENS211", name: "Engineering Mathematics", color: "#0078D4" },
  { code: "PRE211", name: "Probability & Statistics", color: "#00B7C3" },
  { code: "CPE481", name: "Computer Architecture", color: "#8764B8" },
  { code: "CPE461", name: "Digital Signal Processing", color: "#CA5010" },
];

export function Dashboard() {
  const navigate = useNavigate();
  const [examDuration, setExamDuration] = useState("30");

  const handleStartExam = (subjectCode: string) => {
    navigate(`/exam/${subjectCode}?duration=${examDuration}`);
  };

  return (
    <div className="flex h-screen bg-[#F3F3F3] overflow-hidden">
      <Sidebar />

      <main className="flex-1 overflow-y-auto">
        {/* Header */}
        <header className="bg-white border-b border-[#E1E1E1] px-8 py-4 backdrop-blur-xl bg-opacity-95">
          <h1 className="text-2xl font-semibold text-[#1F1F1F]">CBT Dashboard</h1>
          <p className="text-sm text-[#717171] mt-1">Select a subject to begin your examination</p>
        </header>

        {/* Main Content */}
        <div className="p-8 max-w-7xl mx-auto">
          {/* Configuration Section */}
          <div className="bg-white rounded-xl border border-[#E1E1E1] p-6 mb-8 shadow-sm">
            <div className="flex items-center gap-4">
              <Clock className="size-5 text-[#0078D4]" />
              <label className="text-[15px] font-medium text-[#1F1F1F]">
                Select Exam Duration
              </label>
              <select
                value={examDuration}
                onChange={(e) => setExamDuration(e.target.value)}
                className="ml-auto px-4 py-2 border border-[#E1E1E1] rounded-lg bg-white text-[#1F1F1F] hover:border-[#0078D4] focus:border-[#0078D4] focus:outline-none focus:ring-2 focus:ring-[#0078D4]/20 transition-all duration-200"
              >
                <option value="15">15 Minutes</option>
                <option value="30">30 Minutes</option>
                <option value="45">45 Minutes</option>
                <option value="60">60 Minutes</option>
              </select>
            </div>
          </div>

          {/* Subject Grid */}
          <div className="grid grid-cols-2 gap-6">
            {subjects.map((subject) => (
              <div
                key={subject.code}
                className="bg-white rounded-xl border border-[#E1E1E1] p-6 shadow-sm hover:shadow-md transition-all duration-200 hover:border-[#0078D4]/30"
              >
                <div className="flex items-start gap-4">
                  <div
                    className="size-12 rounded-xl flex items-center justify-center shadow-sm"
                    style={{ backgroundColor: subject.color }}
                  >
                    <BookOpen className="size-6 text-white" />
                  </div>

                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-[#1F1F1F] mb-1">
                      {subject.code}
                    </h3>
                    <p className="text-sm text-[#717171] mb-4">{subject.name}</p>

                    <div className="flex items-center gap-3">
                      <FluentButton
                        variant="primary"
                        onClick={() => handleStartExam(subject.code)}
                        className="text-sm px-6"
                      >
                        Start Exam
                      </FluentButton>
                      <FluentButton variant="secondary" className="text-sm px-6">
                        View Details
                      </FluentButton>
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="mt-6 pt-6 border-t border-[#F3F3F3] flex gap-6 text-sm">
                  <div>
                    <span className="text-[#717171]">Questions:</span>
                    <span className="ml-2 font-medium text-[#1F1F1F]">24</span>
                  </div>
                  <div>
                    <span className="text-[#717171]">Total Points:</span>
                    <span className="ml-2 font-medium text-[#1F1F1F]">48</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
