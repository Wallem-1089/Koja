import { InputHTMLAttributes } from "react";
import { cn } from "./ui/utils";

interface FluentRadioProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  option: string;
}

export function FluentRadio({
  label,
  option,
  className,
  checked,
  ...props
}: FluentRadioProps) {
  return (
    <label
      className={cn(
        "flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all duration-200",
        checked
          ? "border-[#0078D4] bg-[#F6FAFE]"
          : "border-[#E1E1E1] bg-white hover:border-[#C7C7C7] hover:bg-[#FAFAFA]",
        className
      )}
    >
      <div className="relative flex items-center justify-center">
        <input
          type="radio"
          checked={checked}
          className="peer appearance-none size-5 rounded-full border-2 border-[#717171] checked:border-[#0078D4] checked:border-[6px] transition-all duration-200 cursor-pointer"
          {...props}
        />
      </div>
      <span className="flex-1 text-[15px]">
        <span className="font-medium mr-2">{option}.</span>
        {label}
      </span>
    </label>
  );
}
