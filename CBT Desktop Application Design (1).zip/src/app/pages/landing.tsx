import { useEffect } from "react";
import { useNavigate } from "react-router";
import logo from "figma:asset/d281d1b0ab406e9ef59623eb1823fb04a7be32ea.png";

export function Landing() {
  const navigate = useNavigate();

  useEffect(() => {
    // Auto-navigate to dashboard after 2 seconds, or user can click
    const timer = setTimeout(() => {
      navigate("/dashboard");
    }, 2500);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div
      className="h-screen flex items-center justify-center bg-gradient-to-br from-[#E8E4DC] to-[#D4CFC4] cursor-pointer"
      onClick={() => navigate("/dashboard")}
    >
      <div className="flex flex-col items-center gap-8">
        <img
          src={logo}
          alt="ACES Logo"
          className="w-64 h-64 object-contain animate-fade-in"
        />
        
        <div className="flex gap-2 mt-4">
          <div className="size-2 rounded-full bg-[#0078D4] animate-pulse" style={{ animationDelay: "0ms" }} />
          <div className="size-2 rounded-full bg-[#0078D4] animate-pulse" style={{ animationDelay: "150ms" }} />
          <div className="size-2 rounded-full bg-[#0078D4] animate-pulse" style={{ animationDelay: "300ms" }} />
        </div>
      </div>
    </div>
  );
}
