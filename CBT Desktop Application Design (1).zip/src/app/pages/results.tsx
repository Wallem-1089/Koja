import { useLocation, useNavigate } from "react-router";
import { FluentButton } from "../components/fluent-button";
import { Trophy, Home, BarChart3, CheckCircle, XCircle } from "lucide-react";
import { useEffect, useState } from "react";

export function Results() {
  const navigate = useNavigate();
  const location = useLocation();
  const [animatedScore, setAnimatedScore] = useState(0);
  
  const { answers = {}, totalQuestions = 24, subject = "Unknown" } = location.state || {};
  
  // Calculate score (simplified - in real app would check against correct answers)
  const answeredCount = Object.keys(answers).length;
  const score = answeredCount * 2; // 2 points per question
  const totalPoints = totalQuestions * 2;
  const percentage = ((score / totalPoints) * 100).toFixed(1);

  // Animate score on mount
  useEffect(() => {
    const duration = 1500; // 1.5 seconds
    const steps = 60;
    const increment = score / steps;
    let current = 0;
    
    const timer = setInterval(() => {
      current += increment;
      if (current >= score) {
        setAnimatedScore(score);
        clearInterval(timer);
      } else {
        setAnimatedScore(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [score]);

  const getPerformanceMessage = () => {
    const percent = parseFloat(percentage);
    if (percent >= 90) return { text: "Outstanding!", color: "#107C10" };
    if (percent >= 75) return { text: "Excellent!", color: "#00B7C3" };
    if (percent >= 60) return { text: "Good Job!", color: "#0078D4" };
    if (percent >= 50) return { text: "Fair", color: "#CA5010" };
    return { text: "Needs Improvement", color: "#D13438" };
  };

  const performance = getPerformanceMessage();

  return (
    <div className="min-h-screen bg-[#F3F3F3] flex items-center justify-center p-8">
      <div className="max-w-2xl w-full">
        {/* Main Results Card */}
        <div className="bg-white rounded-xl border border-[#E1E1E1] shadow-lg overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#0078D4] to-[#00B7C3] px-8 py-6 text-white">
            <div className="flex items-center gap-3 mb-2">
              <Trophy className="size-8" />
              <h1 className="text-2xl font-semibold">Exam Results</h1>
            </div>
            <p className="text-sm opacity-90">{subject}</p>
          </div>

          {/* Score Display */}
          <div className="p-8 text-center border-b border-[#E1E1E1]">
            <div className="mb-6">
              <div className="inline-flex items-center justify-center size-48 rounded-full border-8 border-[#0078D4] bg-[#F6FAFE] mb-4 relative">
                <div className="text-center">
                  <div className="text-5xl font-bold text-[#0078D4] mb-1">
                    {animatedScore}/{totalPoints}
                  </div>
                  <div className="text-3xl font-semibold" style={{ color: performance.color }}>
                    {percentage}%
                  </div>
                </div>
              </div>
              <div
                className="text-2xl font-semibold mb-2"
                style={{ color: performance.color }}
              >
                {performance.text}
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto">
              <div className="bg-[#F6FAFE] rounded-xl p-4 border border-[#0078D4]/20">
                <CheckCircle className="size-6 text-[#107C10] mx-auto mb-2" />
                <div className="text-2xl font-bold text-[#1F1F1F]">{answeredCount}</div>
                <div className="text-xs text-[#717171] mt-1">Answered</div>
              </div>

              <div className="bg-[#FFF4CE] rounded-xl p-4 border border-[#CA5010]/20">
                <BarChart3 className="size-6 text-[#CA5010] mx-auto mb-2" />
                <div className="text-2xl font-bold text-[#1F1F1F]">{totalQuestions}</div>
                <div className="text-xs text-[#717171] mt-1">Total Questions</div>
              </div>

              <div className="bg-[#FDE7E9] rounded-xl p-4 border border-[#D13438]/20">
                <XCircle className="size-6 text-[#D13438] mx-auto mb-2" />
                <div className="text-2xl font-bold text-[#1F1F1F]">
                  {totalQuestions - answeredCount}
                </div>
                <div className="text-xs text-[#717171] mt-1">Unanswered</div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="p-8 bg-[#FAFAFA]">
            <div className="flex gap-4 justify-center">
              <FluentButton
                variant="secondary"
                onClick={() => navigate("/dashboard")}
                className="gap-2 px-8"
              >
                <Home className="size-5" />
                Return to Home Page
              </FluentButton>

              <FluentButton variant="secondary" className="gap-2 px-8">
                <BarChart3 className="size-5" />
                View Rank
              </FluentButton>
            </div>

            <p className="text-center text-sm text-[#717171] mt-6">
              Your results have been saved to your history
            </p>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-6 text-center text-sm text-[#717171]">
          <p>
            Wednesday, March 11, 2026 •{" "}
            {new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </p>
        </div>
      </div>
    </div>
  );
}