import { createBrowserRouter } from "react-router";
import { Landing } from "./pages/landing";
import { Dashboard } from "./pages/dashboard";
import { Exam } from "./pages/exam";
import { Results } from "./pages/results";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Landing,
  },
  {
    path: "/dashboard",
    Component: Dashboard,
  },
  {
    path: "/exam/:subject",
    Component: Exam,
  },
  {
    path: "/results",
    Component: Results,
  },
]);