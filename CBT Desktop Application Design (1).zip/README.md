
  # CBT Desktop Application Design

  This is a code bundle for CBT Desktop Application Design. The original project is available at https://www.figma.com/design/qtaDxQNdXNMuoYLp7OP80a/CBT-Desktop-Application-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  