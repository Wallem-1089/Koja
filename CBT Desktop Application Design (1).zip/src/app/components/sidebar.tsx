import { Home, Clock, Settings } from "lucide-react";
import { cn } from "./ui/utils";
import { useLocation, useNavigate } from "react-router";

export function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { icon: Home, label: "Home", path: "/dashboard" },
    { icon: Clock, label: "History", path: "/history" },
    { icon: Settings, label: "Settings", path: "/settings" },
  ];

  return (
    <aside className="w-20 bg-[#FAFAFA] border-r border-[#E1E1E1] flex flex-col items-center py-6 gap-4 backdrop-blur-xl">
      <div className="size-12 rounded-xl bg-[#0078D4] flex items-center justify-center mb-4 shadow-md">
        <span className="text-white text-xl font-semibold">C</span>
      </div>

      <div className="flex flex-col gap-2 w-full px-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={cn(
                "flex flex-col items-center justify-center p-3 rounded-lg transition-all duration-200 group",
                isActive
                  ? "bg-[#0078D4] text-white shadow-md"
                  : "text-[#717171] hover:bg-[#F3F3F3] hover:text-[#1F1F1F]"
              )}
              title={item.label}
            >
              <Icon className="size-6" />
            </button>
          );
        })}
      </div>
    </aside>
  );
}